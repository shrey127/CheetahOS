pyttsx is a Python package supporting common text-to-speech engines on Mac OS X, Windows, and Linux.


